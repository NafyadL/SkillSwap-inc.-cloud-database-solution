<?php
/*
Config file
*/
$config['servername'] =  "35.199.37.28";
$config['username'] = "skillswap";
$config['password'] = "HUnl0921@";
$config['database'] = "skillswapdb";
?>
